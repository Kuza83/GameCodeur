using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControlShip : MonoBehaviour
{
    [SerializeField] private float translationSpeed;
    [SerializeField]private float rotationSpeed;
    private const float MinX = 23f;
    private const float MaxX = -23f;
    private const float MaxY = 60f;
    private const float MinY = 5f;
    private const float MinCamY = MinY + 5f;
    private const float MaxCamY = MaxY + 5f;

    private GameObject cameraExt;
    private GameObject cameraInt;
    private bool cameraExtActive;

    public GameObject laser;
    [SerializeField] public List<GameObject> listLaser;

    [SerializeField] private float moveSpeed;
    private float _currentSpeed = 0;
    
    // Start is called before the first frame update
    void Start()
    {
        transform.position = new Vector3(0, 25, 0);
        cameraExt = GameObject.Find("cameraExt");
        cameraInt = GameObject.Find("cameraInt");
        laser = GameObject.Find("Laser");
        
        cameraExt.SetActive(true);
        cameraInt.SetActive(false);
        cameraExtActive = true;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.RightShift) & cameraExtActive)
        {
            cameraInt.SetActive(true);
            cameraExt.SetActive(false);
            cameraExtActive = false;
        }
        
        else if (Input.GetKeyDown(KeyCode.RightShift))
        {
            cameraExt.SetActive(true);
            cameraInt.SetActive(false);
            cameraExtActive = true;
        }
        
    // DEPLACEMENT HAUTEUR Y
        float verticalMove = Input.GetAxis("Vertical") * translationSpeed * Time.deltaTime;
        transform.position += transform.up * -verticalMove;
        cameraExt.transform.position += transform.up * -verticalMove;

        if (transform.position.y > MaxY)
        {
            transform.position = new Vector3(transform.position.x, MaxY, transform.position.z);
            cameraExt.transform.position = new Vector3(cameraExt.transform.position.x, MaxCamY, cameraExt.transform.position.z);
        }
        
        if (transform.position.y <= MinY)
        {
            transform.position = new Vector3(transform.position.x, MinY, transform.position.z);
            cameraExt.transform.position = new Vector3(cameraExt.transform.position.x, MinCamY, cameraExt.transform.position.z);
        }

    // DEPLACEMENT TRANSERVAL X
    
        if (Input.GetAxis("Horizontal") !=0)
        {
            float rotationMove = Input.GetAxis("Horizontal") * -rotationSpeed + Time.deltaTime;
            transform.Rotate(0,0,rotationMove);
        }
        else
        {
            transform.Rotate(0,0,0);
        }

        
        if (transform.position.x < MaxX)
        {
            transform.position = new Vector3(MaxX, transform.position.y, transform.position.z);
            cameraExt.transform.position = new Vector3(MaxX, cameraExt.transform.position.y, cameraExt.transform.position.z);
        }

        if (transform.position.x > MinX)
        {
            transform.position = new Vector3(MinX, transform.position.y, transform.position.z);
            cameraExt.transform.position = new Vector3(MinX, cameraExt.transform.position.y, cameraExt.transform.position.z);
        }

    // DEPLACEMENT VERS L'AVANT Z

        if (Input.GetButton("Fire2"))
        {
            _currentSpeed += 0.5f * Time.deltaTime;
            if (_currentSpeed > moveSpeed)
            {
                _currentSpeed = moveSpeed;
            }
        }
        else if (Input.GetButton("Fire1"))
        {
            _currentSpeed -= 1f * Time.deltaTime;
        }
        else
        {
            if (_currentSpeed > 0) 
            {
                _currentSpeed -= 0.1f * Time.deltaTime;
                if (_currentSpeed < 0)
                {
                    _currentSpeed = 0;
                }
            }    
        }
        transform.position += transform.forward * _currentSpeed; 
        cameraExt.transform.position += transform.forward * _currentSpeed;
    }

    private void OnTriggerEnter(Collider other)
    {
        GameControler.Instance.Health -= 10;
    }
}
