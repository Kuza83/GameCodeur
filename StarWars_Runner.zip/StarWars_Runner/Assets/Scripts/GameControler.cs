using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Serialization;
using UnityEngine.UI;


public class GameControler : MonoBehaviour
{
    public static GameControler Instance;

    [SerializeField] private GameObject[] groundsPrefabs;
    
    [SerializeField] private GameObject[] groundsOnStage;
    [SerializeField] public int Health;

    [SerializeField] private Image HealthBar;
    //[SerializeField] private Image ShieldBar;
    [SerializeField] private Image BackBar;
    
    private float groundSize;
    private GameObject Ship;

    private void Awake()
    {
        if (Instance != null)
        {
            Destroy(gameObject);
        }
        Instance = this;
        
        Health = 100;
    }
    // Start is called before the first frame update
    void Start()
    {
        
        
        Ship = GameObject.Find("Ship");
        
        groundsOnStage = new GameObject[groundsPrefabs.Length];
        
        for (int i = 0 ; i < groundsPrefabs.Length ; i++)
        {
            int n = Random.Range(0, groundsPrefabs.Length);
            groundsOnStage[i] = Instantiate(groundsPrefabs[n]);
        }

        groundSize = 470; //groundsOnStage[0].GetComponentInChildren<Transform>().Find("Road").localScale.z;
        Debug.Log(groundSize);
        float pos = -245f + groundSize;
        foreach (var ground in groundsOnStage)
        {
            ground.transform.position = new Vector3(0, 0.2f, pos);
            pos += groundSize;
        }
    }

    // Update is called once per frame
    void Update()
    {
        for (int i = groundsOnStage.Length - 1; i >= 0; i--)
        {
            GameObject ground = groundsOnStage[i];
            if (ground.transform.position.z + groundSize / 2 < Ship.transform.position.z - 6f)
            {
                float z = ground.transform.position.z;
                Destroy(ground);
                int n = Random.Range(0, groundsPrefabs.Length);
                ground = Instantiate(groundsPrefabs[n]);
                ground.transform.position = new Vector3(0, 0.2f, z + groundSize * groundsPrefabs.Length);
                groundsOnStage[i] = ground;
            }
        }

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }

        float healthRatio = Health / 100f;
        HealthBar.rectTransform.sizeDelta = new Vector2(BackBar.rectTransform.sizeDelta.x * healthRatio, BackBar.rectTransform.sizeDelta.y);
        
        if (Health <= 0)
        {
            gameOver();
        }
    }

    private void OnDestroy()
    {
        Instance = null;
    }

    public void gameOver()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }
}
